from flask import Flask, render_template, request, redirect, session, url_for
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from flask_compress import Compress
import os
from datetime import datetime

app = Flask(__name__)

# ضغط الملفات لتسريع الموقع
compress = Compress(app)

# استخدام المسار المطلق لقاعدة البيانات
basedir = os.path.abspath(os.path.dirname(__file__))

# إعدادات قاعدة البيانات الذكية (SQLite على الجهاز، PostgreSQL على السحابة)
if os.environ.get('DATABASE_URL'):
    db_url = os.environ.get('DATABASE_URL')
    if db_url.startswith('postgres://'):
        db_url = db_url.replace('postgres://', 'postgresql://', 1)
    app.config['SQLALCHEMY_DATABASE_URI'] = db_url
else:
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'studyhub.db')

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'studyhub-secret-key-2024')

# 🔐 لمسات الأمان: تأمين الكوكيز
if not app.debug and os.environ.get('PYTHONANYWHERE_DOMAIN'):
    app.config['SESSION_COOKIE_SECURE'] = True
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'

app.config['UPLOAD_FOLDER'] = os.path.join(basedir, 'uploads')
app.config['ALLOWED_EXTENSIONS'] = {'pdf', 'png', 'jpg', 'jpeg', 'mp3', 'mp4'}
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50 ميجابايت

# التأكد من وجود مجلد uploads
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)
    university_year = db.Column(db.String(20), nullable=False)
    major = db.Column(db.String(50), nullable=False)

class Course(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    university_year = db.Column(db.String(20), nullable=False)
    major = db.Column(db.String(50), nullable=False)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

class Material(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(200), nullable=False)
    file_type = db.Column(db.String(20), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'), nullable=False)
    upload_date = db.Column(db.DateTime, default=datetime.utcnow)

# 🔐 لمسات الأمان: إضافة هيدرات حماية
@app.after_request
def add_security_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    return response

# --- دوال التطبيق ---
@app.route('/')
def home():
    return render_template('home.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        full_name = request.form['full_name']
        email = request.form['email']
        password = generate_password_hash(request.form['password'])
        year = request.form['university_year']
        major = 'عام' if year in ['أولى', 'ثانية'] else request.form.get('major', 'عام')
        if not major or major == '':
            major = 'عام'
        new_user = User(full_name=full_name, email=email, password=password, university_year=year, major=major)
        db.session.add(new_user)
        db.session.commit()
        return redirect('/login')
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['user_name'] = user.full_name
            session['user_year'] = user.university_year
            session['user_major'] = user.major
            return redirect('/dashboard')
        else:
            return render_template('login.html', error="الإيميل أو كلمة المرور غير صحيحة")
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect('/login')
    if session['user_major'] == 'عام':
        user_courses = Course.query.filter_by(university_year=session['user_year']).all()
    else:
        user_courses = Course.query.filter_by(university_year=session['user_year'], major=session['user_major']).all()
    return render_template('dashboard.html', user_name=session['user_name'], courses=user_courses)

@app.route('/course/<int:course_id>')
def course_detail(course_id):
    if 'user_id' not in session:
        return redirect('/login')
    course = Course.query.get_or_404(course_id)
    materials = Material.query.filter_by(course_id=course_id).all()
    return render_template('course_detail.html', course=course, materials=materials)

@app.route('/course/<int:course_id>/upload', methods=['POST'])
def upload_file(course_id):
    if 'user_id' not in session:
        return redirect('/login')
    
    if 'file' not in request.files:
        return redirect(url_for('course_detail', course_id=course_id))
    
    file = request.files['file']
    file_type = request.form['file_type']
    
    if file.filename == '':
        return redirect(url_for('course_detail', course_id=course_id))
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        new_material = Material(
            filename=filename,
            file_type=file_type,
            course_id=course_id
        )
        db.session.add(new_material)
        db.session.commit()
        print(f"✅ تم رفع الملف: {filename}")
    
    return redirect(url_for('course_detail', course_id=course_id))

@app.route('/add-sample-courses')
def add_sample_courses():
    Course.query.delete()
    courses_data = [
        ('رياضيات 1', 'تفاضل وتكامل - أساسيات', 'أولى', 'عام'),
        ('فيزياء 1', 'ميكانيكا كلاسيكية', 'أولى', 'عام'),
        ('كيمياء عامة', 'أساسيات الكيمياء', 'أولى', 'عام'),
        ('مقدمة في البرمجة', 'Python Basics', 'أولى', 'عام'),
        ('رياضيات 2', 'جبر خطي ومعادلات تفاضلية', 'ثانية', 'عام'),
        ('فيزياء 2', 'كهربية ومغناطيسية', 'ثانية', 'عام'),
        ('تحليل عددي', 'Numerical Analysis', 'ثالثة', 'هندسة'),
        ('دوائر كهربية', 'Electric Circuits', 'ثالثة', 'هندسة'),
        ('باثولوجي', 'Pathology', 'ثالثة', 'طب'),
        ('فارماكولوجي', 'Pharmacology', 'ثالثة', 'طب')
    ]
    for name, desc, year, major in courses_data:
        course = Course(name=name, description=desc, university_year=year, major=major)
        db.session.add(course)
    db.session.commit()
    return redirect('/dashboard')

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

def init_db():
    with app.app_context():
        db.create_all()
        print("✅ تم إنشاء الجداول.")
        if Course.query.count() == 0:
            courses_data = [
                ('رياضيات 1', 'تفاضل وتكامل - أساسيات', 'أولى', 'عام'),
                ('فيزياء 1', 'ميكانيكا كلاسيكية', 'أولى', 'عام'),
                ('كيمياء عامة', 'أساسيات الكيمياء', 'أولى', 'عام'),
                ('مقدمة في البرمجة', 'Python Basics', 'أولى', 'عام'),
                ('رياضيات 2', 'جبر خطي ومعادلات تفاضلية', 'ثانية', 'عام'),
                ('فيزياء 2', 'كهربية ومغناطيسية', 'ثانية', 'عام'),
                ('تحليل عددي', 'Numerical Analysis', 'ثالثة', 'هندسة'),
                ('دوائر كهربية', 'Electric Circuits', 'ثالثة', 'هندسة'),
                ('باثولوجي', 'Pathology', 'ثالثة', 'طب'),
                ('فارماكولوجي', 'Pharmacology', 'ثالثة', 'طب')
            ]
            for name, desc, year, major in courses_data:
                course = Course(name=name, description=desc, university_year=year, major=major)
                db.session.add(course)
            db.session.commit()
            print("✅ تمت إضافة المواد التجريبية تلقائياً.")
        else:
            print(f"📚 عدد المواد الموجودة: {Course.query.count()}")

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        print("✅ تم إنشاء الجداول أو التأكد من وجودها.")
        if Course.query.count() == 0:
            init_db()
    port = int(os.environ.get('PORT', 5000))
    app.run(debug=True, host='0.0.0.0', port=port)
else:
    with app.app_context():
        db.create_all()
        print("✅ تم إنشاء الجداول على السحابة.")